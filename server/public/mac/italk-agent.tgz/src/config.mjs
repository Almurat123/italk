import { homedir, hostname, networkInterfaces } from 'node:os';
import { existsSync, mkdirSync, readFileSync, writeFileSync, chmodSync } from 'node:fs';
import { execFileSync } from 'node:child_process';
import path from 'node:path';
import { MODES } from './policy.mjs';
import { CloudAccess, GatewayModelClient } from './cloud.mjs';
import { ITalkAgentBackend } from './agent/loop.mjs';

export const DEFAULT_PORT = 47321;
export const stateDirDefault = () => path.join(homedir(), 'Library', 'Application Support', 'iTalk Agent');
export const logDirDefault = () => path.join(homedir(), 'Library', 'Logs', 'iTalk Agent');

const DEFAULTS = {
  name: null, port: DEFAULT_PORT, publicUrls: [], roots: ['~'], maxPermissionMode: 'ask', approvalTimeoutMinutes: 30, retentionDays: 30, maxConcurrentTasks: 2, maxSteps: 60,
};

export function loadConfig(dir) {
  const file = path.join(dir, 'config.json');
  let stored = {};
  if (existsSync(file)) { try { stored = JSON.parse(readFileSync(file, 'utf8')); } catch (error) { throw new Error(`config.json is not valid JSON: ${error.message}`); } }
  const config = { ...DEFAULTS, ...stored };
  delete config.backends;                        // older versions let a computer be pointed at other model servers; that is no longer possible
  if (!MODES.includes(config.maxPermissionMode)) throw new Error(`maxPermissionMode must be one of ${MODES.join(', ')}`);
  config.name ??= computerName();
  return config;
}

export function saveConfig(dir, config) {
  mkdirSync(dir, { recursive: true, mode: 0o700 });
  const file = path.join(dir, 'config.json');
  writeFileSync(file, JSON.stringify(config, null, 2) + '\n', { mode: 0o600 });
  chmodSync(file, 0o600);
}

export function computerName() {
  try { return execFileSync('scutil', ['--get', 'ComputerName'], { encoding: 'utf8', timeout: 2000 }).trim() || hostname(); } catch { return hostname(); }
}

/** Where the phone can reach this computer: current LAN addresses, the .local name (survives address changes), and any public URLs configured. */
export function endpoints({ port, publicUrls = [] }) {
  const out = [];
  let local = null;
  try { local = execFileSync('scutil', ['--get', 'LocalHostName'], { encoding: 'utf8', timeout: 2000 }).trim(); } catch {}
  if (local) out.push(`https://${local}.local:${port}`);
  const priority = (name) => (name.startsWith('en') ? 0 : 1);
  const lan = [];
  for (const [name, list] of Object.entries(networkInterfaces())) for (const a of list ?? []) if (a.family === 'IPv4' && !a.internal && /^(10\.|192\.168\.|172\.(1[6-9]|2\d|3[01])\.)/.test(a.address)) lan.push({ name, address: a.address });
  lan.sort((a, b) => priority(a.name) - priority(b.name));
  for (const { address } of lan) out.push(`https://${address}:${port}`);
  for (const u of publicUrls) out.push(u.replace(/\/+$/, ''));
  return [...new Set(out)];
}

export function lanAddresses() {
  const out = [];
  for (const list of Object.values(networkInterfaces())) for (const a of list ?? []) if (a.family === 'IPv4' && !a.internal) out.push(a.address);
  return out;
}

export class SessionStore {
  constructor(db, now = () => Date.now()) { this.db = db; this.now = now; }
  load(id) { const row = this.db.prepare('SELECT data FROM backend_sessions WHERE id=?').get(id); return row ? JSON.parse(row.data) : null; }
  save(id, backend, data) { this.db.prepare('INSERT INTO backend_sessions(id,backend,data,updated_at) VALUES(?,?,?,?) ON CONFLICT(id) DO UPDATE SET data=excluded.data, updated_at=excluded.updated_at').run(id, backend, JSON.stringify(data), this.now()); }
  purge(olderThanMs) { return this.db.prepare('DELETE FROM backend_sessions WHERE updated_at<?').run(this.now() - olderThanMs).changes; }
}

/**
 * The agent has exactly one backend: the iTalk agent, which reasons through iTalk's gateway with the credential the paired phone provides.
 * There is no way to configure another provider, endpoint or key, and no local model server or third-party agent is started or detected.
 */
export async function createBackends(config, { db, home = homedir(), fetcher = fetch, stateDir, keychain, web, opener, sleep, now, log } = {}) {
  const sessions = new SessionStore(db);
  const access = new CloudAccess({ stateDir, keychain, fetcher });
  const client = new GatewayModelClient({ access, fetcher, sleep, log });
  const map = new Map();
  map.sessions = sessions; map.access = access;
  map.set('italk', new ITalkAgentBackend({ access, client, sessions, home, stateDir, web, opener, maxSteps: config.maxSteps, now, log }));
  return map;
}
